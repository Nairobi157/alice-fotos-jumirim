
from flask import Flask, request, redirect, session, send_from_directory, render_template_string
from werkzeug.utils import secure_filename
from datetime import datetime
import sqlite3, os, urllib.parse

app = Flask(__name__)
app.secret_key = "foto-jumirim-2026"
UPLOAD_FOLDER = "/tmp/static/uploads"
DB_PATH = "/tmp/fotos.db"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

SENHA = "666777"
WHATSAPP = "5515996216025"

def init_db():
    try:
        con = sqlite3.connect(DB_PATH)
        con.execute("CREATE TABLE IF NOT EXISTS fotos (id INTEGER PRIMARY KEY, filename TEXT, titulo TEXT, categoria TEXT, data TEXT, likes INTEGER DEFAULT 0)")
        con.execute("CREATE TABLE IF NOT EXISTS agendamentos (id INTEGER PRIMARY KEY, nome TEXT, whatsapp TEXT, tipo TEXT, data_evento TEXT, horario TEXT, local TEXT, mensagem TEXT, status TEXT, criado TEXT)")
        con.commit()
        con.close()
    except: pass

def get_fotos():
    try:
        init_db()
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        fotos = con.execute("SELECT * FROM fotos ORDER BY id DESC").fetchall()
        con.close()
        return fotos
    except:
        return []

def get_agendamentos():
    try:
        init_db()
        con = sqlite3.connect(DB_PATH)
        con.row_factory = sqlite3.Row
        ag = con.execute("SELECT * FROM agendamentos ORDER BY id DESC").fetchall()
        con.close()
        return ag
    except:
        return []

@app.route('/static/uploads/<path:filename>')
def serve_upload(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route("/")
def index():
    fotos = get_fotos()
    return render_template_string(PUBLIC_HTML, fotos=fotos, whatsapp=WHATSAPP)

@app.route("/agendar", methods=["POST"])
def agendar():
    init_db()
    nome = request.form.get("nome","")
    whatsapp_cli = request.form.get("whatsapp","")
    tipo = request.form.get("tipo","")
    data_evento = request.form.get("data_evento","")
    horario = request.form.get("horario","")
    local = request.form.get("local","")
    mensagem = request.form.get("mensagem","")
    
    con = sqlite3.connect(DB_PATH)
    con.execute("INSERT INTO agendamentos (nome,whatsapp,tipo,data_evento,horario,local,mensagem,status,criado) VALUES (?,?,?,?,?,?,?, 'Pendente',?)", (nome, whatsapp_cli, tipo, data_evento, horario, local, mensagem, datetime.now().strftime("%d/%m/%Y %H:%M")))
    con.commit()
    con.close()
    
    msg = f"Olá! Sou {nome}, quero agendar {tipo} no dia {data_evento} as {horario} em {local}. {mensagem} Meu Whats: {whatsapp_cli}"
    link = f"https://wa.me/{WHATSAPP}?text={urllib.parse.quote(msg)}"
    return redirect(link)

@app.route("/admin", methods=["GET","POST"])
def admin_page():
    if request.method == "POST":
        if request.form.get("senha") == SENHA:
            session["admin"] = True
            return redirect("/admin")
    if not session.get("admin"):
        return render_template_string(ADMIN_LOGIN_HTML)
    fotos = get_fotos()
    agendamentos = get_agendamentos()
    return render_template_string(ADMIN_PANEL_HTML, fotos=fotos, agendamentos=agendamentos, whatsapp=WHATSAPP)

@app.route("/admin/logout")
def admin_logout():
    session.pop("admin", None)
    return redirect("/admin")

@app.route("/upload", methods=["POST"])
def upload():
    if not session.get("admin"):
        return redirect("/admin")
    file = request.files.get("foto")
    if file and file.filename:
        filename = datetime.now().strftime("%Y%m%d%H%M%S_") + secure_filename(file.filename)
        file.save(os.path.join(UPLOAD_FOLDER, filename))
        con = sqlite3.connect(DB_PATH)
        con.execute("INSERT INTO fotos (filename,titulo,categoria,data,likes) VALUES (?,?,?,?,0)", (filename, request.form.get("titulo","Foto"), request.form.get("categoria","Ensaio"), datetime.now().strftime("%d/%m/%Y")))
        con.commit()
        con.close()
    return redirect("/admin")

@app.route("/delete/<int:foto_id>")
def delete_foto(foto_id):
    if not session.get("admin"):
        return redirect("/admin")
    con = sqlite3.connect(DB_PATH)
    row = con.execute("SELECT filename FROM fotos WHERE id=?", (foto_id,)).fetchone()
    if row:
        try: os.remove(os.path.join(UPLOAD_FOLDER, row[0]))
        except: pass
        con.execute("DELETE FROM fotos WHERE id=?", (foto_id,))
        con.commit()
    con.close()
    return redirect("/admin")

@app.route("/like/<int:foto_id>")
def like(foto_id):
    try:
        con = sqlite3.connect(DB_PATH)
        con.execute("UPDATE fotos SET likes=likes+1 WHERE id=?", (foto_id,))
        con.commit()
        con.close()
    except: pass
    return redirect("/")

PUBLIC_HTML = """
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alice Fotos - Jumirim</title>
<style>
body{background:#0a0a0a;color:#fff;font-family:Arial;margin:0}
.card{background:#111;border:1px solid #222;border-radius:12px;overflow:hidden}
.card img{width:100%;height:220px;object-fit:cover}
header{padding:25px;text-align:center;border-bottom:1px solid #222}
h1{color:#d4af37}
input,select,textarea{width:100%;padding:12px;background:#1a1a1a;border:1px solid #222;border-radius:8px;color:#fff;margin:6px 0;box-sizing:border-box}
button{background:#d4af37;color:#000;border:none;padding:12px;border-radius:8px;font-weight:bold;cursor:pointer}
</style>
</head><body>
<header>
<h1>Alice • Fotos Jumirim</h1>
<p style="color:#888">Fotógrafa em Cerquilho, Tietê, Jumirim e região • 500+ ensaios • 5.0 ★</p>
<a href="#agendar" style="background:#d4af37;color:#000;padding:12px 25px;border-radius:30px;text-decoration:none;display:inline-block;margin-top:10px;font-weight:bold">📅 Agendar Ensaio</a>
<a href="https://wa.me/{{whatsapp}}" style="background:#25D366;color:#fff;padding:12px 25px;border-radius:30px;text-decoration:none;display:inline-block;margin-top:10px;margin-left:10px">💬 WhatsApp</a>
</header>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:20px;padding:30px;max-width:1200px;margin:auto">
{% for f in fotos %}
<div class="card"><img src="/static/uploads/{{f['filename']}}"><div style="padding:12px"><b>{{f['titulo']}}</b> - <small style="color:#d4af37">{{f['categoria']}}</small><br><small style="color:#666">{{f['data']}} • ❤️ {{f['likes']}}</small><br><a href="/like/{{f['id']}}" style="color:#d4af37;text-decoration:none">❤️ Curtir</a></div></div>
{% endfor %}
{% if not fotos %}<div style="grid-column:1/-1;text-align:center;padding:50px;color:#888"><h3>Em breve fotos novas aqui! ✨</h3><p>Enquanto isso, agende seu ensaio abaixo!</p></div>{% endif %}
</div>

<div id="agendar" style="background:#111;border-top:1px solid #222;padding:40px 20px">
<div style="max-width:600px;margin:auto">
<h2 style="color:#d4af37;text-align:center">📅 Agendar Ensaio / Evento</h2>
<p style="color:#888;text-align:center">O cliente preenche aqui e já vai pro seu WhatsApp + fica salvo no seu painel admin!</p>
<form action="/agendar" method="post" style="background:#0a0a0a;border:1px solid #222;padding:20px;border-radius:12px;margin-top:20px">
<input name="nome" placeholder="Seu nome" required>
<input name="whatsapp" placeholder="Seu WhatsApp (com DDD)" required>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
<select name="tipo"><option>Ensaio Feminino</option><option>Ensaio Casal</option><option>Casamento</option><option>Aniversário</option><option>Evento</option><option>Formatura</option><option>Outro</option></select>
<input name="data_evento" type="date" required>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
<input name="horario" type="time"><input name="local" placeholder="Local: ex: Jumirim">
</div>
<textarea name="mensagem" placeholder="Conte mais sobre o que você quer... (opcional)" rows="3"></textarea>
<button type="submit" style="width:100%;margin-top:10px">📲 Enviar e Falar no WhatsApp</button>
<p style="color:#555;font-size:11px;text-align:center;margin-top:10px">Ao enviar, você será redirecionado pro WhatsApp da fotógrafa</p>
</form>
</div>
</div>

<footer style="text-align:center;padding:30px;color:#555;border-top:1px solid #111"><a href="/admin" style="color:#333;text-decoration:none">Área da fotógrafa</a></footer>
</body></html>
"""

ADMIN_LOGIN_HTML = """
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin - Alice</title></head>
<body style="background:#0a0a0a;color:white;font-family:Arial;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
<div style="background:#111;border:1px solid #222;padding:30px;border-radius:16px;max-width:350px;width:90%;text-align:center">
<h2 style="color:#d4af37">Área da Fotógrafa</h2><p style="color:#888;font-size:13px">Admin separado</p>
<form method="post" style="margin-top:20px">
<input type="password" name="senha" placeholder="Senha: 666777" style="width:100%;padding:12px;background:#1a1a1a;border:1px solid #222;border-radius:8px;color:white">
<button style="width:100%;padding:12px;background:#d4af37;border:none;border-radius:8px;font-weight:bold;margin-top:10px">Entrar</button>
</form>
<a href="/" style="color:#555;font-size:12px;display:block;margin-top:15px">← Voltar pro site</a>
</div></body></html>
"""

ADMIN_PANEL_HTML = """
<html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Painel - Alice</title>
<style>body{background:#0a0a0a;color:#fff;font-family:Arial;margin:0} .card{background:#111;border:1px solid #222;border-radius:12px;overflow:hidden} .card img{width:100%;height:150px;object-fit:cover} input,select{padding:10px;background:#1a1a1a;border:1px solid #222;color:#fff;border-radius:6px;width:100%;box-sizing:border-box;margin:4px 0}</style>
</head><body>
<header style="background:#d4af37;color:#000;padding:15px;display:flex;justify-content:space-between;align-items:center">
<div><b>PAINEL ADMIN</b></div><div><a href="/" style="color:#000;margin-right:15px">Ver site público</a><a href="/admin/logout" style="color:#000;font-weight:bold">Sair</a></div>
</header>
<div style="max-width:1100px;margin:auto;padding:20px">

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
<div style="background:#111;border:1px solid #222;border-radius:12px;padding:20px">
<h3 style="color:#d4af37;margin-top:0">+ Postar Foto</h3>
<form action="/upload" method="post" enctype="multipart/form-data">
<input type="file" name="foto" required><br>
<input name="titulo" placeholder="Título" required><br>
<select name="categoria"><option>Ensaio</option><option>Casamento</option><option>Evento</option><option>Retrato</option><option>Natureza</option></select><br>
<button style="width:100%;background:#d4af37;padding:12px;border:none;border-radius:6px;font-weight:bold;margin-top:10px">POSTAR</button>
</form>
</div>

<div style="background:#111;border:1px solid #222;border-radius:12px;padding:20px">
<h3 style="color:#d4af37;margin-top:0">📅 Agendamentos ({{agendamentos|length}})</h3>
<div style="max-height:300px;overflow-y:auto">
{% for ag in agendamentos %}
<div style="background:#0a0a0a;border:1px solid #222;padding:10px;border-radius:8px;margin:8px 0;font-size:13px">
<b>{{ag['nome']}}</b> - {{ag['tipo']}}<br>
📅 {{ag['data_evento']}} {{ag['horario']}} - 📍 {{ag['local']}}<br>
📱 {{ag['whatsapp']}}<br>
<small style="color:#888">{{ag['mensagem']}}</small><br>
<small style="color:#555">{{ag['criado']}} - {{ag['status']}}</small><br>
<a href="https://wa.me/{{ag['whatsapp']}}" style="color:#25D366;font-size:12px">Responder no WhatsApp</a>
</div>
{% endfor %}
{% if not agendamentos %}<p style="color:#888">Nenhum agendamento ainda. Quando o cliente preencher no site, aparece aqui!</p>{% endif %}
</div>
</div>
</div>

<h3 style="margin-top:30px">Suas fotos ({{fotos|length}})</h3>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:15px">
{% for f in fotos %}
<div class="card"><img src="/static/uploads/{{f['filename']}}"><div style="padding:10px"><b>{{f['titulo']}}</b><br><small>{{f['categoria']}} - ❤️ {{f['likes']}}</small><br><a href="/delete/{{f['id']}}" style="color:#ff6666;font-size:12px" onclick="return confirm('Apagar?')">🗑️ Apagar</a></div></div>
{% endfor %}
</div>

</div></body></html>
"""

app = app
